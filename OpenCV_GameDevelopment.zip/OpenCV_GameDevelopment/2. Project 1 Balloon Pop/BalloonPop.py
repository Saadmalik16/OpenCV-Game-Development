# Imports
import pygame
import cv2
import numpy as np
import random
import HandDetectorModule as hdm
import time

# Initialize
pygame.init()

# Create/Window Display
width, height = 640, 480
window = pygame.display.set_mode((width,height))
pygame.display.set_caption("Balloon Pop")

# Initialize Clock for FPS
fps = 30
clock = pygame.time.Clock()

# WebCam
cap = cv2.VideoCapture(0)
cap.set(3, 640) #width
cap.set(4, 480) #height

# Image
imgRedBalloon = pygame.image.load('../Resources/RedBaloon.png').convert_alpha()
imgRedBalloon = pygame.transform.rotozoom(imgRedBalloon, 0, 0.8)
rectRedBalloon = imgRedBalloon.get_rect()
rectRedBalloon.x, rectRedBalloon.y = 200, 240

#Variables
speed = 10
score = 0
startTime = time.time()
totalTime = 2

# Detector
detector = hdm.HandDetector(detectionCon=0.8, maxHands=1)

def resetBallon():
    rectRedBalloon.x = random.randint(50, img.shape[1] - 50)
    rectRedBalloon.y = img.shape[0] + 20

#Main Loop
start = True
while start:

    # Get Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            start = False
            pygame.quit()

    # Apply Logic
    timeRemain = int(totalTime - (time.time() - startTime))
    if timeRemain <0:
        window.fill((255, 255, 255))
        font = pygame.font.Font('../Resources/arial.ttf', 30)
        textScore = font.render(f'Your Score is {score}', True, (50, 50, 255))
        textTime = font.render("Game Over", True, (50, 50, 255))
        window.blit(textScore, (190, 230))
        window.blit(textTime, (210, 170))

    else:
        # Open CV
        success, img = cap.read()
        img = cv2.flip(img, 1)
        hands, img = detector.findHands(img, flipType=False)

        #Balloon is moving up
        rectRedBalloon.y -= speed

        #Check if balloon has reached the top without pop
        if rectRedBalloon.y < 0:
            resetBallon()
            speed += 1

        #Check for hand and tip that touches balloon
        if hands:
            hand = hands[0]
            x, y = hand['lmList'][8]
            if rectRedBalloon.collidepoint(x, y):
                resetBallon()
                score += 10
                speed += 1

        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        imgRGB = np.rot90(imgRGB)
        frame = pygame.surfarray.make_surface(imgRGB).convert()
        frame = pygame.transform.flip(frame, True, False)
        window.blit(frame, (0,0))
        window.blit(imgRedBalloon, rectRedBalloon)

        font = pygame.font.Font('../Resources/arial.ttf', 20)
        textScore = font.render(f'Your Score: {score}', True, (50, 50, 255))
        textTime = font.render(f'Time: {timeRemain}', True, (50, 50, 255))
        window.blit(textScore, (25, 25))
        window.blit(textTime, (500, 25))

    #Update Display
    pygame.display.update()

    #Set FPS
    clock.tick(fps)