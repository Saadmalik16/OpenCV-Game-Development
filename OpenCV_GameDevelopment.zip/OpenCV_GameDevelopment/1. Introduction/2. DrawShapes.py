# Imports
import pygame

# Initialize
pygame.init()

# Create/Window Display
width, height = 640, 480
window = pygame.display.set_mode((width,height))
pygame.display.set_caption("Pygame Template")

# Initialize Clock for FPS
fps = 30
clock = pygame.time.Clock()

#Main Loop
start = True
while start:

    # Get Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            start = False
            pygame.quit()

    # Apply Logic
    window.fill((255, 255, 255))
    red, green, blue = (255, 0, 0), (0, 255, 0), (0, 0, 255)
    pygame.draw.polygon(window, red, ((191, 100), (391, 100), (447, 240),
                                      (391, 357), (191, 357), (137, 240)))
    pygame.draw.circle(window, green, (290, 230), 100)
    pygame.draw.line(window, blue, (200, 200), (380, 200), 10)
    pygame.draw.rect(window, blue, (220, 250, 200, 40), border_radius=5)
    #Update Display
    pygame.display.update()

    #Set FPS
    clock.tick(fps)