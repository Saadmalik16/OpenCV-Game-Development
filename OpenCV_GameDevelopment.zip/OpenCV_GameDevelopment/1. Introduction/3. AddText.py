# Imports
import pygame

# Initialize
pygame.init()

# Create/Window Display
width, height = 640, 480
window = pygame.display.set_mode((width,height))
pygame.display.set_caption("Pygame Template")

# Initialize Clock for FPS
fps = 30
clock = pygame.time.Clock()

#Main Loop
start = True
while start:

    # Get Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            start = False
            pygame.quit()

    # Apply Logic
    window.fill((255, 255, 255))
    #font = pygame.font.Font(None, 80)
    font = pygame.font.Font('../Resources/arial.ttf', 80)
    text = font.render("My Game", True, (50, 50, 50))
    window.blit(text, (150, 150))
    #Update Display
    pygame.display.update()

    #Set FPS
    clock.tick(fps)