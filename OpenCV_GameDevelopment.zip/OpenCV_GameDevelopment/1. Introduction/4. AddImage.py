# Imports
import pygame

# Initialize
pygame.init()

# Create/Window Display
width, height = 640, 480
window = pygame.display.set_mode((width,height))
pygame.display.set_caption("Pygame Template")

# Initialize Clock for FPS
fps = 30
clock = pygame.time.Clock()

#Add Image
imgBackground = pygame.image.load("Resources/BackgroundImage.jpg").convert()
imgBaloonRed = pygame.image.load("Resources/RedBaloon.png").convert_alpha()

#Main Loop
start = True
while start:

    # Get Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            start = False
            pygame.quit()

    # Apply Logic
    window.blit(imgBackground, (0,0))
    window.blit(imgBaloonRed, (200, 240))

    #Update Display
    pygame.display.update()

    #Set FPS
    clock.tick(fps)